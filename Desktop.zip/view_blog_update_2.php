<?php
include 'connet.php';

      $id = $_POST['id'];
      $Title = $_POST['Title'];
      $Description = $_POST['Description'];
      $old_img=$_POST['old_img'];

  if (isset($_POST['submit'])) {

    if (isset($_FILES['img']['name']) && ($_FILES['img']['name'] !="")) {
      $size=$_FILES['img']['size'];
      $temp=$_FILES['img']['tmp_name'];
      $type=$_FILES['img']['type'];
      $profile_name=$_FILES['img']['name'];
      //delete
      unlink("Blog_img/$old_img");
      //update
      move_uploaded_file($temp, "Blog_img/$profile_name");
    }else{
      $profile_name=$old_img;
    }
    $update=mysqli_query($conn,"UPDATE blog SET Title='$Title',Description='$Description',Img='$profile_name'  WHERE id='$id'");

    if ($update) {
      echo "<script>alert('update succes!')</script>";
    }else{
      echo "<script>alert('update faild!')</script>";
    }
}
echo "ok";



?>